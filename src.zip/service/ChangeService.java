package service;

import java.io.File;
import java.util.ArrayList;

import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.PictureNode;

public class ChangeService {

	public static Stage stage;
	public static ArrayList<File> files;
	public static File file ;
	public static ImageView origin,change;
	public static double originHight,originWidth;
	
}
